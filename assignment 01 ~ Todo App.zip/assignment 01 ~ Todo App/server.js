const express = require("express");
const app = express();


//database
const database = [];


// post requests
// add tasks
app.post("/", express.json(), function(req, res) {
    Array.from(req.body, (task) => {
        database.push(task);
    })
    res.sendStatus("201");
});


// get requests
app.get("/", (req, res) => {
    res.json(database);
});

app.get("/at", express.json(), (req, res) => {
    const index = req.body[0];
    res.send(database[index]);
});

app.get("/sort", (req, res) => {
    database.sort();
    res.json(database);
});


// put requests
// update task
app.put("/", express.json(), (req, res) => {
    const index = req.body[0];
    const newContent = req.body[1];
    database[index] = newContent + "(completed)";
    res.sendStatus("200");
});


// delete requests
app.delete("/", express.json(), (req, res) => {
    const index = req.body[0];
    database.splice(index, 1);
    res.sendStatus("200");
});



app.listen(3000, () => {
    console.log("todo-app server is now running...");
});